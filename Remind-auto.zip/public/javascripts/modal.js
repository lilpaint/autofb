$(document).ready(function () {
    var modal = $('.modal');
    var btn = $('.btn');
    var span = $('.close');
  
    btn.click(function () {
      modal.show();
    });
  
    span.click(function () {
      modal.hide();
    });
  
    $(window).on('click', function (e) {
      if ($(e.target).is('.modal')) {
        modal.hide();
      }
    });
  });
  