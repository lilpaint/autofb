var express = require('express');
var router = express.Router();
var db=require('../models/database'); 


module.exports = router;